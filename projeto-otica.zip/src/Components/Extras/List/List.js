export const List = ({listType, listItems}) => {
    
    // return (
    //     <ul>
    //         {listItems.map(item => {<li>{item}</li>})}
    //     </ul>
    // )

    if (listType == "ul") {
        return (
            <li>
                <p>oi</p>
            </li>
        )
    } else if (listType == "ol") {

    }
}